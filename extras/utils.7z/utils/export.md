All of the LUA APIs in this page!

Includes all VARIABLES, FUNCTIONS and EVENTS on all and what they do!

If there's something below, but don't know what they do? You can use CTRL+F and find which function or variable and then see what it does for the function, event or variable!

<small>This was generated, click [here](https://github.com/NAEL2XD/LuApps/blob/main/extras/main.py) for the code.</small>

There are a total of:
* 58 functions.
* 16 variables.
* 4 events.

# Functions
### `addSprite(tag:String, ?front:Bool = false)`
Adds the sprite inside the game using tag's `tag` and then either making it go to `front` or not.

**Args**:
* `tag` - The tag name for the sprite.
* `front` *(Optional)* - Whatever or not you want it to be on the front or not.

### `addText(tag:String)`
Adds the tag named `tag` to display text in there.

**Args**:
* `tag` - The text's tag name.

### `cancelTimer(tag:String)`
Cancels a Timer created with `runTimer`.

**Args**:
* `tag` - Timer's Lua name tag.

### `cancelTween(tag:String)`
Cancels a Tween created with any of the Tween functions.

**Args**:
* `tag` - Tween's tag.

### `clearConsole()`
Clears the console from the window, will increase performance well.

### `collectGarbage(void)`
Cleans up memory.

### `doTweenAlpha(tag:String, vars:String, value:Dynamic, duration:Float, ?ease:String = 'linear')`
Starts a simple tween to change the Sprite's Alpha and call function `tweenCompleted` when it ends. Returns the formatted Tween tag.

**Args**:
* `tag` - Tween tag for the `tweenCompleted` function, it should be unique or it will overwrite the previous one with the same name.
* `vars` - Sprite variable name or Sprite nametag.
* `value` - Target value at the end of the tween.
* `duration` - Tween duration (in seconds).
* `ease` *(Optional)* - [Tween ease](https://api.haxeflixel.com/flixel/tweens/FlxEase.html), defaults to `"linear"`.

### `doTweenAngle(tag:String, vars:String, value:Dynamic, duration:Float, ?ease:String = 'linear')`
Starts a simple tween to change the Sprite's Angle and call function `tweenCompleted` when it ends. Returns the formatted Tween tag.

**Args**:
* `tag` - Tween tag for the `tweenCompleted` function, it should be unique or it will overwrite the previous one with the same name.
* `vars` - Sprite variable name or Sprite nametag.
* `value` - Target value at the end of the tween.
* `duration` - Tween duration (in seconds).
* `ease` *(Optional)* - [Tween ease](https://api.haxeflixel.com/flixel/tweens/FlxEase.html), defaults to `"linear"`.

### `doTweenColor(tag:String, vars:String, targetColor:String, duration:Float, ?ease:String = 'linear')`
Starts a simple tween to change the Sprite's Color and call function `tweenCompleted` when it ends. Returns the formatted Tween tag.

**Args**:
* `tag` - Tween tag for the `tweenCompleted` function, it should be unique or it will overwrite the previous one with the same name.
* `vars` - Sprite variable name or Sprite nametag.
* `value` - Target value at the end of the tween.
* `duration` - Tween duration (in seconds).
* `ease` *(Optional)* - [Tween ease](https://api.haxeflixel.com/flixel/tweens/FlxEase.html), defaults to `"linear"`.

### `doTweenX(tag:String, vars:String, value:Dynamic, duration:Float, ?ease:String = 'linear')`
Starts a simple tween to change the Sprite's X and call function `tweenCompleted` when it ends. Returns the formatted Tween tag.

**Args**:
* `tag` - Tween tag for the `tweenCompleted` function, it should be unique or it will overwrite the previous one with the same name.
* `vars` - Sprite variable name or Sprite nametag.
* `value` - Target value at the end of the tween.
* `duration` - Tween duration (in seconds).
* `ease` *(Optional)* - [Tween ease](https://api.haxeflixel.com/flixel/tweens/FlxEase.html), defaults to `"linear"`.

### `doTweenY(tag:String, vars:String, value:Dynamic, duration:Float, ?ease:String = 'linear')`
Starts a simple tween to change the Sprite's Y and call function `tweenCompleted` when it ends. Returns the formatted Tween tag.

**Args**:
* `tag` - Tween tag for the `tweenCompleted` function, it should be unique or it will overwrite the previous one with the same name.
* `vars` - Sprite variable name or Sprite nametag.
* `value` - Target value at the end of the tween.
* `duration` - Tween duration (in seconds).
* `ease` *(Optional)* - [Tween ease](https://api.haxeflixel.com/flixel/tweens/FlxEase.html), defaults to `"linear"`.

### `exit()`
Exits the LuApplication.

### `get(variable:String)` -> `?`
Returns the value of a property or variable for sprites or texts, a variable saved through `setVar` or a Lua Sprite/Text.

**Args**:
* `variable` - Variable or Property.

### `getColorFromFlx(color:String = '')` -> `FlxColor`
Alias for `FlxColor`.

**Args**:
* `color` - Color hexadecimal string or [color name](https://api.haxeflixel.com/flixel/util/FlxColor.html).

### `getContent(path:String)` -> `string`
Loads a File as text and returns its content. If the file couldn't be found, it will return null.

**Args**:
* `file` - File name path.

### `getDistance(tag1:String, tag2:String)` -> `float`
Gets the sprite or text's tag distance and returns the value.

**Args**:
* `tag1` - The first sprite or text tag.
* `tag2` - The second sprite or text tag.

### `keyJustPressed(name:String)` -> `boolean`
Returns whether a specific keyboard button just got pressed.

**Args**:
* `button` - [Click here for the full list of buttons](https://api.haxeflixel.com/flixel/input/keyboard/FlxKey.html)

### `keyPressed(name:String)` -> `boolean`
Returns whether a specific keyboard button is being pressed.

**Args**:
* `button` - [Click here for the full list of buttons](https://api.haxeflixel.com/flixel/input/keyboard/FlxKey.html)

### `makeGraphic(obj:String, ?width:Int = 256, ?height:Int = 256, ?color:String = "FFFFFF")`
Generates a solid color square as graphic for a Lua Sprite.

**Args**:
* `tag` - Sprite variable name or Lua Sprite nametag.
* `width` *(Optional)* - Graphic width in pixels. Defaults to 256.
* `height` *(Optional)* - Graphic height in pixels. Defaults to 256.
* `color` *(Optional)* - Color hexadecimal string or [color name](https://api.haxeflixel.com/flixel/util/FlxColor.html).

### `makeSprite(tag:String, ?image:String, ?x:Float = 0, ?y:Float = 0)`
Makes a Sprite with a tag names `tag` with the image `image` on position `x` and `y`.

## Note that if another `tag` exists and is the same as what your tag is inputted, it will be overwritten!

**Args**:
* `tag` - The name of your sprite tag that can be used to edit and customize it.
* `image` *(Optional)* - The image you currently want to use, Image location is on `assets/images/*.png`.
* `x` *(Optional)* - The X position to use.
* `y` *(Optional)* - The Y position to use.

### `makeText(tag:String, text:String, width:Int, x:Float, y:Float)`
Makes a text with the tag named `tag` and the text being `text` with the width being `width` on position `x` and `y`

**ARGS**:
* `tag` - The text's tag.
* `text` - The name of the text you wanna use.
* `width` - The width of the text you wanna use, recommended to use 1280.
* `x` - The x's position.
* `y` - The y's position.

### `mouseClicked(button:String)` -> `boolean`
Returns whether the Mouse button just got clicked in this frame.

**Args**:
* `button` - Can be: `"left"`, `"middle"` or `"right"`. Defaults to `"left"`

### `mousePressed(button:String)` -> `?button:String = 'left'`
Returns whether the Mouse button is being held currently.

**Args**:
* `button` - Can be: `"left"`, `"middle"` or `"right"`.

### `move(tag:String, xy:String = "xy", px:Float = 10)`
Moves a sprite's tag or text's tag's x or y position.

**Args**:
* `tag` - The sprite or text tag.
* `xy` *(Optional)* - Type of position to move, Available `xy` are `"x"`, `"y"`, `"xy"`.
* `px` *(Optional)* - How much pixels to move.

### `moveTowardsMouse(tag:String, speed:Int = 60)`
Moves a sprite to the mouse at pixel speed to 60 or something else.

**Args**:
* `tag` - The sprite's tag to use.
* `speed` - The speed by pixel.

### `objectsOverlap(obj1:String, obj2:String)` -> `boolean`
Returns whether two Object hitboxes are overlapping each other, useful for collision checking.

**Args**:
* `obj1` - Variable name of the instance or Lua Object nametag of the first object.
* `obj2` - Variable name of the instance or Lua Object nametag of the second object.

### `playMusic(music:String, ?volume:Float = 1, ?loop:Bool = false)`
Plays a music, used for Pre/Post Song cutscenes.

**Args**:
* `music` - Music path inside "assets/music/" folder, don't include the extension!
* `volume` *(Optional)* - Ranges from 0 to 1, defaults to 1.
* `loop` *(Optional)* - Should sound loop indefinitely?

### `playSound(sound:String)`
Plays a sound with the path `sound`.

**Args**:
* `sound` - Sound path inside "assets/sounds/" folder, don't include the extension!

### `print(text:String)`
`print`s the text on the window's console.

**Args**:
* `text` - The text you want to input.

### `randomBool(?chance:Float = 50)` -> `boolean`
Randomizer that returns either `true` or `false`.

**Args**:
* `chance` - Ranges from 0 to 100. Defaults to 50%

### `randomFloat(?min:Float = 0, ?max:Float = 1)` -> `float`
Randomizer that returns a float value.

**Args**:
* `min` *(Optional)* - Minimal number to randomize, defaults to 0.
* `max` *(Optional)* - Max number to randomize, defaults to 1.

### `randomInt(?min:Int = 1, ?max:Int = 10)` -> `int`
Randomizer that returns an integer value.

**Args**:
* `min` *(Optional)* - Minimal number to randomize, defaults to 1.
* `max` *(Optional)* - Max number to randomize, defaults to 10.

### `removeSprite(tag:String)`
Removes the sprite named `tag` and will be destroyed to free up memory.

**Args**:
* `tag` - The sprite's tag name to destroy.

### `removeText(tag:String)`
Removes the text's `tag` and destroys it and cleans up ram.

**Args**:
* `tag` - The text's tag name to destroy it.

### `resetWindowSize()`
Resets the window size to the currently set window size from Prefs.

### `runTimer(tag:String)`
Runs a timer and triggers it to `timerComplete`.

### `scaleObject(obj:String, x:Float, y:Float, updateHitbox:Bool = true)`
Scales an Object by a ratio.

**Args**:
* `tag` - Variable name of the instance or Lua Object nametag.
* `x` - Scale ratio X.
* `y` - Scale ratio Y.

### `screenCenter(obj:String, pos:String = 'xy')`
Centers an Object to the Screen on the specified axis.

**Args**:
* `tag` - Variable name of the instance or Lua Object nametag.
* `axis` *(Optional)* - can be `"X"`, `"Y"` or `"XY"`, defaults to `"XY"`.

### `sendPopup(?title:String = "", desc:String = "")`
Uses the window api to send a popup with the title being `title` and the description being `desc`.

**Args**:
* `title` *(Optional)* - The title name to set, defaults to mod name if nothing is set..
* `desc` - The description for the popup.

### `set(variable:String, value:Dynamic)`
Sets the value of a property or variable inside PlayState, a variable saved through `setVar` or a Lua Sprite/Text. Returns "value".

**Args**:
* `variable` - Variable or Property.
* `value` - Value to set.

### `setBlend(obj:String, blend:String = '')` -> `boolean`
Changes the Blend Mode of an object, similarly to various image editors. Returns whether the operation was successful.

**Args**:
* `tag` - Variable name of the instance or Lua Object nametag.
* `blend` - [Blend mode name](https://api.haxeflixel.com/flash/display/BlendMode.html), leave empty for using the default blend mode.

*Note: Some blend modes like "OVERLAY" just seem to not work at all!*

### `setClipboardText(text:String)`
Overwrites the current clipboard text to the current text argument.

**Args**:
* `text` - The text you want to overwrite.

### `setIcon(image:String)`
Sets the window's icon to the image set.

**Args**:
* `image` - Image name from `mods\[mod name]\assets\images`.

### `setMouseVisibility(?show:Bool = true)`
Sets the mouse's visibility using the `show` argument

**Args**:
* `show` *(Optional)* - Whatever or not you want to show the cursor, Defaults to `true` if nothing is set.

### `setTextAlignment(tag:String, alignment:String = 'left')` -> `boolean`
Changes a Text's Alignment. Returns `true` if the operation was successful, throws a warning if text object is missing and returns `false`.

**Args**:
* `tag` - Text instance variable/Lua Text nametag.
* `alignment` - Can be: `"left"`, `"right"`, `"center"`. Defaults to `"left"`.

### `setTextBorder(tag:String, size:Float, color:String)` -> `boolean`
Changes a Text's Border properties. Returns `true` if the operation was successful, throws an error if text object is missing and returns `false`.

**Args**:
* `tag` - Text instance variable/Lua Text nametag.
* `size` - Border thickness.
* `color` - Color hexadecimal string.

### `setTextBorderStyle(tag:String, style:String, hexColor:String, ?size:Float = 1, ?quality:Float = 1)` -> `boolean`
Sets the text's border properties that you can set or change the border properties.

**ARGS**:
* `tag` - The text's tag name.
* `style` - What style to use, Can be: `"shadow"`, `"outline"` and `"outlinefast"`, Defaults to `"NONE"` if there is nothing set or doesn't exist.
* `hexColor` - The hexadecimal color to use, can be `0xAARRGGBB` or `RRGGBB`.
* `size` *(Optional)* - The size for the border.
* `quality` *(Optional)* - The quality you want to set.

### `setTextColor(tag:String, color:String)` -> `boolean`
Changes a Text's color. Returns `true` if the operation was successful, throws an error if text object is missing and returns `false`.

**Args**:
* `tag` - Text instance variable/Lua Text nametag.
* `color` - Color hexadecimal string.

### `setTextFont(tag:String, newFont:String)` -> `boolean`
Changes a Text's font. Returns `true` if the operation was successful, throws an error if text object is missing and returns `false`.

**Args**:
* `tag` - Text instance variable/Lua Text nametag.
* `font` - Text font path.

### `setTextSize(tag:String, size:Int)` -> `boolean`
Sets the text's `tag` size to `size`.

**ARGS**:
* `tag` - The text's `tag` name to set the size to.
* `size` - The text you want to set.

### `setTextString(tag:String, text:String)` -> `boolean`
Sets the text's `tag` string to `text`.

**ARGS**:
* `tag` - The text's `tag` name to set the text to.
* `text` - The text you want to set.

### `setWindowName(name:String)`
Sets the window name to whatever you want!

**Args**:
* `name` - The name of the window you wanna set.

### `setWindowSize(?width:Int = 1280, ?height:Int = 720)`
Sets the window size to whatever input you set.

**Args**:
* `width` *(Optional)* - Pixel Width to use.
* `height` *(Optional)* - Pixel Height to use.

### `stringEndsWith(str:String, end:String)` -> `boolean`
Check if `str` ends with `end`.

**Args**:
* `str` - String being checked.
* `end` - String to check if the previous value ends with it.

### `stringSplit(str:String, split:String)` -> `array`
Shortcut for `String.split` in Lua.

**Args**:
* `str` - String being checked.
* `split` - String delimiter.

### `stringStartsWith(str:String, start:String)` -> `boolean`
Shortcut for `StringTools.startsWith` in Lua.

**Args**:
* `str` - String being checked.
* `start` - String to check if the previous value starts with it.

### `stringTrim(str:String)` -> `string`
Clears the spaces at the start and end of a string.

**Args**:
* `str` - String being checked.

### `switchApp(title:String = "Choose a file.", filter:String = "*")` -> `string`
Switches the app from Currently running LuApp to The new one to load..

**Args**:
* `name` - The LuApp to load on mods folder, it should load this: `mods/(name)/source/main.lua`



# Variables
### `author` -> `string`
Returns the author of this LuApplication.

### `clipboardItem` -> `string`
Returns the text stored in the clipboard.

### `fps` -> `int`
Returns the current FPS running.

### `fullscreen` -> `boolean`
Returns if the window is in fullscreen.

### `height` -> `int`
Returns the window's height.

### `lowDetail` -> `boolean`
Returns if the user has set the low detail on or off.

### `memory` -> `string`
Returns the current memory usage.

### `mempeak` -> `string`
Returns the maximum memory usage.

### `modName` -> `string`
Returns the LuApps name.

### `modRaw` -> `string`
Returns the LuApps raw mod folder name.

### `mouseMoved` -> `boolean`
Returns if the mouse has been moved by the user.

### `mouseX` -> `int`
Returns the mouse's X Position.

### `mouseY` -> `int`
Returns the mouse's Y Position.

### `time` -> `float`
Returns how long the LuApplication has been ran for.

### `version` -> `string`
Returns the LuApps version.

### `width` -> `int`
Returns the window's width.


# Events
### `create()`
Called after this script has been fully initialized.

### `timerComplete(tag:String, loops:Int, loopsLeft:Int)`
Called when a timer with a `tag` finishes.

### `tweenCompleted(tag:String, ?vars:String)`
Called when a tween with a `tag` finishes.

### `update(elapsed:Float)`
Called on each game frame update.

